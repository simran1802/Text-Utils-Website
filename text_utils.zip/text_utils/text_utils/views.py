from django.shortcuts import HttpResponse
from django.shortcuts import render

def index(request):
    params = {'name' : 'Simran' , 'place' : 'Fateh Nagar'}
    return render(request,'index.html')

def about(request):
    return HttpResponse('''<h1> About Simran </h1> <a href="https://hacktoberfest.digitalocean.com/profile"> Django Hacktoberfest </a>''')

def analyze(request):

    # Get the text
    djtext = request.POST.get('text','default')

    name = request.POST.get('name','off')
    fullcaps = request.POST.get('fullcaps','off')
    newlineremove = request.POST.get('newlineremove','off')
    spaceremover = request.POST.get('spaceremover','off')
    charcount = request.POST.get('charcount','off')

    if name == "on":
        punct = '''!()-[]{};:'"\,<>./?@#$%^&*_~'''
        analyzed = ""
        for char in djtext:
            if char not in punct:
                analyzed += char

        params = {'purpose':'Remove Punctuation','analyzed_text':analyzed}
        djtext = analyzed

    if(fullcaps == 'on'):
        analyzed = ""
        for char in djtext:
            analyzed = analyzed+char.upper()

        params = {'purpose': 'Changed to uppercase', 'analyzed_text': analyzed}
        djtext = analyzed

    if(newlineremove == 'on'):
        analyzed = ""
        for char in djtext:
            if char != "\n" and char != "\r":
                analyzed += char
        params = {'purpose': 'Remove new lines', 'analyzed_text': analyzed}
        djtext = analyzed

    if (spaceremover == 'on'):
        analyzed = ""
        for index ,char in enumerate(djtext):
            if not (djtext[index] == " " and djtext[index+1] == " "):
                analyzed += char

        params = {'purpose': 'Remove Extra spaces', 'analyzed_text': analyzed}
        djtext = analyzed

    if (charcount == 'on'):
        analyzed = ""
        for char in djtext:
            analyzed = len(djtext)


        params = {'purpose': 'Counts Number of characters', 'analyzed_text': analyzed}
        djtext = analyzed

    return render(request, 'analyze.html', params)
